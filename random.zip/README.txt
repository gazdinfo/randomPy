Véletlenszám generáló programok

Fájlok feladata:
  - randgen.py: tartalmazza a véletlenszám generáláshoz használt két algoritmust: lineáris és additív kongruenciális metódusok, valamint értéket ad az algoritmusok működéséhez szükséges változóknak
  - custom.py: a program különböző paramméterekkel hívható meg, melyekkel átállíthatóak az algoritmusokban használt alapértékek. (segítséghez: -h paraméter)
  - additive.py: egy véleten számot generál additív módszerrel (paraméterként megadható, egész-szám alakban: [N min max])
  - linear.py: egy véleten számot generál lineáris módszerrel (paraméterként megadható, egész-szám alakban: [N min max])
  - pic.py: egy véletlenszerű karakteres-képet generál
  - stat.py: egy fájlban lévő számsorozatról (minden szám külön sorban) megvizsgálja, hogy véletlenszerű-e. Paraméterként meg kell adni a fájl nevét és a maximumértéket
